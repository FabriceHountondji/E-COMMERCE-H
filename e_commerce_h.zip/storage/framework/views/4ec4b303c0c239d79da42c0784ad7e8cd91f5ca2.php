<?php $__env->startSection('content'); ?>

<div class="app-main__inner">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <h5 class="card-title">Formulaire de modification acteurs</h5>
            <form id="signupForm" class="col-md-10 mx-auto" method="post" action="<?php echo e(route('acteurs.update', $acteur->id)); ?>" enctype="multipart/form-data">

                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PUT')); ?>


                <div class="form-group">
                    <label for="firstname">Prénom(s)</label>
                    <div>
                        <input type="text" class="form-control" id="firstname" name="firstname" placeholder="First name" value="<?php echo e(old('firstname') ? old('firstname') : $acteur->firstname); ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="lastname">Nom</label>
                    <div>
                        <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Last name" value="<?php echo e(old('lastname') ? old('lastname') : $acteur->lastname); ?>" />
                    </div>
                </div>
                <div class="form-group">
                    <label for="phone">Numéro de Téléphone</label>
                    <div>
                        <input type="text" class="form-control" id="phone" name="phone" placeholder="N-Téléphone" value="<?php echo e(old('phone') ? old('phone') : $acteur->phone); ?>" />
                    </div>
                </div>
                <div class="form-group">
                    <label for="birthday">Date de naissance</label>
                    <input type="text" class="form-control" data-toggle="datepicker-year" name="birthday" value="<?php echo e(old('birthday') ? old('birthday') : $acteur->birthday); ?>"/>
                </div>

                <div class="position-relative form-group">
                    <label for="exampleSelect" class="">Sexe</label>
                    <select name="sexe" id="exampleSelect" class="form-control">
                        <option value="Masculin" <?php echo e($acteur->sexe == 'Masculin' ? 'selected' : ''); ?> >Masculin</option>
                        <option value="Féminin" <?php echo e($acteur->sexe == 'Féminin' ? 'selected' : ''); ?>>Féminin</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="address">Adresse</label>
                    <div>
                        <input type="text" class="form-control" id="address" name="address" placeholder="Adresse" value="<?php echo e(old('address') ? old('address') : $acteur->address); ?>"/>
                    </div>
                </div>

                <label for="exampleFile"> Profile </label>

                <div class="input-group mb-3">
                    <input type="file" class="form-control" id="inputGroupFile02" name="photo">
                    <label class="input-group-text" for="inputGroupFile02">Télécharger</label>
                </div>

                <div class="position-relative form-group">
                    <label for="exampleSelect" class="">Fonction</label>
                    <select name="fonction_id" id="exampleSelect" class="form-control">
                        <?php $__currentLoopData = $fonctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fonction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($fonction->id); ?>" <?php echo e($acteur->fonction->name == $fonction->name ? 'selected' : ''); ?>> <?php echo e($fonction->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="position-relative form-group">
                    <label for="exampleSelect" class="">Compte utilisateur</label>
                    <select name="user_id" id="exampleSelect" class="form-control">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e($acteur->user->email == $user->email ? 'selected' : ''); ?>> <?php echo e($user->email); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary" name="enregistrer" value="Enregistrer">Enregister les modifications</button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\PROJET_POST_LICENCE\GEST_COMMERCE_1\e_commerce_h\resources\views/acteurs/edit.blade.php ENDPATH**/ ?>