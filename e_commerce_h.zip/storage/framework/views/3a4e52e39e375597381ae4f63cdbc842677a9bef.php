<?php $__env->startSection('content'); ?>

<div class="app-main__inner">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <h5 class="card-title">Formulaire d'enregistrement des images associées aux produits</h5>
            <form id="signupForm" class="col-md-10 mx-auto" method="post" action="<?php echo e(route('imageassocies.store', Route::currentRouteName())); ?>">
                <?php echo csrf_field(); ?>

                <div class="position-relative form-group">
                    <label for="exampleSelect" class="">Produit associé</label>
                    <select name="produit_id" id="exampleSelect" class="form-control">
                        <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($produit->id); ?>"> <?php echo e($produit->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="position-relative form-group">
                    <label for="exampleSelect" class="">Image à associer</label>
                    <select name="image_id" id="exampleSelect" class="form-control">
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($image->id); ?>"> <?php echo e($image->url); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary" name="enregistrer" value="Enregistrer">Enregister</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\PROJET_POST_LICENCE\GEST_COMMERCE_1\e_commerce_h\resources\views/imageassocies/create.blade.php ENDPATH**/ ?>