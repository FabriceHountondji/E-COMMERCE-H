
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success alert-block">
    <div class="header-container-p container">
        <strong>Opération réussie!</strong> <?php echo e($message); ?>

    </div>
</div>
<?php endif; ?>
  
<?php if($message = Session::get('error')): ?>
<div class="alert alert-danger alert-block">
    <div class="header-container-p container">
        <strong>Opération échouée!</strong> <?php echo e($message); ?>

    </div>
</div>
<?php endif; ?>
   
<?php if($message = Session::get('warning')): ?>
<div class="alert alert-warning alert-block">
    <div class="header-container-p container">
        <strong>Avertissement!</strong> <?php echo e($message); ?>

    </div>
</div>
<?php endif; ?>
   
<?php if($message = Session::get('info')): ?>
<div class="alert alert-info alert-block">
    <div class="header-container-p container">
        <strong>Info!</strong> <?php echo e($message); ?>

    </div>
</div>
<?php endif; ?><?php /**PATH C:\wamp64\www\PROJET_POST_LICENCE\GEST_COMMERCE_1\e_commerce_h\resources\views/message-flash/flash.blade.php ENDPATH**/ ?>