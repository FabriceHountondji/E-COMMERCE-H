<?php $__env->startSection('content'); ?>

<div class="app-main__inner">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <h5 class="card-title">Formulaire d'enregistrement produits</h5>
            <form id="signupForm" class="col-md-10 mx-auto" method="post" action="<?php echo e(route('produits.store', Route::currentRouteName())); ?>">
                <?php echo csrf_field(); ?>
                <!-- <div class="form-group">
                    <label for="firstname">Image principale</label>
                    <div>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Mom du produit" />
                    </div>
                </div> -->
                <div class="form-group">
                    <label for="name">Nom</label>
                    <div>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Désignation du produit" required/>
                    </div>
                </div>
                <div class="position-relative form-group">
                    <label for="exampleText" class="">Description</label>
                    <textarea name="description" id="exampleText" class="form-control" required ></textarea>
                </div>
                <div class="form-group">
                    <label for="phone">Prix</label>
                    <div>
                        <input type="text" class="form-control" id="prix" name="prix" placeholder="Prix du produit" required />
                    </div>
                </div>

                <div class="position-relative form-group">
                    <label for="exampleSelect" class="">Catégorie</label>
                    <select name="categorie_id" id="exampleSelect" class="form-control">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"> <?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary" name="enregistrer" value="Enregistrer">Enregister</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\PROJET_POST_LICENCE\GEST_COMMERCE_1\e_commerce_h\resources\views/produits/create.blade.php ENDPATH**/ ?>