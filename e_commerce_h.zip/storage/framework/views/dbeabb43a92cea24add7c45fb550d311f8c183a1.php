<a href="#" title="Supprimer" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#<?php echo e($modal_id); ?>">
    <i class="fa fa-trash"></i> <?php if(!(isset($lite) && $lite)): ?> Supprimer <?php endif; ?>
</a>
 
 <!-- Modal -->
 <div class="modal fade" id="<?php echo e($modal_id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="<?php echo e($modal_id); ?>">Modal de suppression</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e($url); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input name="_method" type="hidden" value="DELETE">
                
                <div class="modal-body">
                
                    <div class="alert alert-danger alert-sm">
                        Confirmer vous vraiment la <b>suppression</b> ?
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button title="Supprimer" type="submit" class="btn btn-danger">Supprimer</button>
                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\PROJET_POST_LICENCE\GEST_COMMERCE_1\e_commerce_h\resources\views/delete/delete.blade.php ENDPATH**/ ?>