<?php $__env->startSection('content'); ?>

<div class="app-main__inner">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <h5 class="card-title">Formulaire de modification fonctions</h5>
            <form id="signupForm" class="col-md-10 mx-auto" method="post" action="<?php echo e(route('fonctions.update', $fonction->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PUT')); ?>


                <div class="form-group">
                    <label for="lastname">Fonction</label>
                    <div>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Entrer la fonction" value="<?php echo e(old('name') ? old('name') : $fonction->name); ?>" required/>
                    </div>
                </div>

                <div class="position-relative form-group">
                    <label for="exampleText" class="">Description</label>
                    <textarea name="description" id="exampleText" class="form-control" required > <?php echo e(old('description') ? old('description') : $fonction->description); ?> </textarea>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary" name="enregistrer" value="Enregistrer">Enregister les modifications</button>
                </div>

            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\PROJET_POST_LICENCE\GEST_COMMERCE_1\e_commerce_h\resources\views/fonctions/edit.blade.php ENDPATH**/ ?>