<?php $__env->startSection('content'); ?>

<div class="app-main__inner">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <h5 class="card-title">Formulaire de modification rôle</h5>
            <form id="signupForm" class="col-md-10 mx-auto" method="post" action="<?php echo e(route('roles.update', $role->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PUT')); ?>


                <div class="form-group">
                    <label for="name">Rôle</label>
                    <div>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Entrer la catégorie" value="<?php echo e(old('name') ? old('name') : $role->name); ?>" required />
                    </div>
                </div>

                <div class="position-relative form-group">
                    <label for="exampleText" class="">Description</label>
                    <textarea name="description" id="exampleText" class="form-control"> <?php echo e(old('description') ? old('description') : $role->description); ?> </textarea>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary" name="enregistrer" value="Enregistrer">Enregister les modifications</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\PROJET_POST_LICENCE\GEST_COMMERCE_1\e_commerce_h\resources\views/roles/edit.blade.php ENDPATH**/ ?>