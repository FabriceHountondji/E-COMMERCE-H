<?php $__env->startSection('content'); ?>

<div class="app-main__inner">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <h5 class="card-title">Formulaire de modification candidats</h5>
            <form id="signupForm" class="col-md-10 mx-auto" method="post" action="<?php echo e(route('users.update', $user->id)); ?>">

                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PUT')); ?>


                <div class="form-group">
                    <label for="username">Username</label>
                    <div>
                        <input type="text" class="form-control" id="username" name="username" placeholder="Username" value="<?php echo e(old('username') ? old('username') : $user->username); ?>" required/>
                    </div>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <div>
                        <input type="email" class="form-control" id="email" name="email" placeholder=" Votre email" value="<?php echo e(old('email') ? old('email') : $user->email); ?>" required/>
                    </div>
                </div>

                <label for="exampleFile"> Profile </label>

                <div class="input-group mb-3">
                    <input type="file" class="form-control" id="inputGroupFile02" name="photo">
                    <label class="input-group-text" for="inputGroupFile02">Télécharger</label>
                </div>

                <div class="position-relative form-group">
                    <label for="exampleSelect" class="">Rôle</label>
                    <select name="role_id" id="exampleSelect" class="form-control">
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->id); ?>" <?php echo e($user->role->name == $role->name ? 'selected' : ''); ?>> <?php echo e($role->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary" name="enregistrer" value="Enregistrer">Enregister les modifications</button>
                </div>
            </form>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\PROJET_POST_LICENCE\GEST_COMMERCE_1\e_commerce_h\resources\views/users/edit.blade.php ENDPATH**/ ?>