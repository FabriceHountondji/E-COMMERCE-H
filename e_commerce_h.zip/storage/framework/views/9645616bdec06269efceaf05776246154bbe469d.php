<?php $__env->startSection('content'); ?>

<div class="app-main__inner">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <h5 class="card-title">Formulaire de modification produits</h5>
            <form id="signupForm" class="col-md-10 mx-auto" method="post" action="<?php echo e(route('produits.update', $produit->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PUT')); ?>


                <!-- <div class="form-group">
                    <label for="firstname">Image principale</label>
                    <div>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Mom du produit" value="<?php echo e(old('name') ? old('name') : $produit->name); ?>" required/>
                    </div>
                </div> -->
                <div class="form-group">
                    <label for="lastname">Nom</label>
                    <div>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Nom du produit" value="<?php echo e(old('name') ? old('name') : $produit->name); ?>" required />
                    </div>
                </div>
                <div class="position-relative form-group">
                    <label for="exampleText" class="">Description</label>
                    <textarea name="description" id="exampleText" class="form-control"  required > <?php echo e(old('description') ? old('description') : $produit->description); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="phone">Prix</label>
                    <div>
                        <input type="text" class="form-control" id="prix" name="prix" placeholder="Prix du produit" value="<?php echo e(old('prix') ? old('prix') : $produit->prix); ?>" required/>
                    </div>
                </div>

                <div class="position-relative form-group">
                    <label for="exampleSelect" class="">Catégorie</label>
                    <select name="categorie_id" id="exampleSelect" class="form-control">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($categorie->id); ?>" <?php echo e($produit->category->name == $category->name ? 'selected' : ''); ?>> <?php echo e($categorie->name); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary" name="enregistrer" value="Enregistrer">Enregister les modifications</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\PROJET_POST_LICENCE\GEST_COMMERCE_1\e_commerce_h\resources\views/produits/edit.blade.php ENDPATH**/ ?>